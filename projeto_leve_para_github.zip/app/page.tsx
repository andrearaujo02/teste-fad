import { DashboardHeader } from "@/components/dashboard/dashboard-header";
import { MetricCard } from "@/components/dashboard/metric-card";
import { AlertsCard } from "@/components/dashboard/alerts-card";
import { PercentageChart } from "@/components/dashboard/charts/percentage-chart";
import { TrendChart } from "@/components/dashboard/charts/trend-chart";
import { METRICS, ALERTS } from "@/lib/constants";

export default function Dashboard() {
  // Sample data for charts
  const leadSourceData = [
    { name: "Orgânico", value: 35, color: "hsl(var(--chart-1))" },
    { name: "Pago", value: 45, color: "hsl(var(--chart-2))" },
    { name: "Afiliados", value: 20, color: "hsl(var(--chart-3))" },
  ];
  
  const conversionTrendData = [
    { date: "Jan", value: 32 },
    { date: "Fev", value: 38 },
    { date: "Mar", value: 35 },
    { date: "Abr", value: 42 },
    { date: "Mai", value: 48 },
    { date: "Jun", value: 52 },
  ];
  
  const engagementTrendData = [
    { date: "Jan", value: 45 },
    { date: "Fev", value: 42 },
    { date: "Mar", value: 47 },
    { date: "Abr", value: 51 },
    { date: "Mai", value: 55 },
    { date: "Jun", value: 59 },
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader title="PAINEL DE CONTROLE - FadTech" />
      <main className="flex-1 p-4 md:p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold tracking-tight md:hidden">
            PAINEL DE CONTROLE - FadTech
          </h1>
          <p className="text-muted-foreground mt-1">
            Dados atualizados em tempo real para suas campanhas e leads.
          </p>
        </div>
        
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {/* Primeira linha - métricas principais */}
          <MetricCard 
            id={METRICS.LEADS_TOTAL.id}
            title={METRICS.LEADS_TOTAL.title}
            value={METRICS.LEADS_TOTAL.value}
            change={METRICS.LEADS_TOTAL.change}
            trend={METRICS.LEADS_TOTAL.trend as "up" | "down" | "neutral"}
            format={METRICS.LEADS_TOTAL.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.OPT_IN_RATE.id}
            title={METRICS.OPT_IN_RATE.title}
            value={METRICS.OPT_IN_RATE.value}
            change={METRICS.OPT_IN_RATE.change}
            trend={METRICS.OPT_IN_RATE.trend as "up" | "down" | "neutral"}
            format={METRICS.OPT_IN_RATE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.LEADS_OPT_IN.id}
            title={METRICS.LEADS_OPT_IN.title}
            value={METRICS.LEADS_OPT_IN.value}
            change={METRICS.LEADS_OPT_IN.change}
            trend={METRICS.LEADS_OPT_IN.trend as "up" | "down" | "neutral"}
            format={METRICS.LEADS_OPT_IN.format as "number" | "percentage" | "currency"}
          />
          <AlertsCard 
            title="Ações Atrasadas"
            items={ALERTS.actions.items}
            status={ALERTS.actions.status}
          />
          
          {/* Segunda linha - métricas de investimento */}
          <MetricCard 
            id={METRICS.INVESTMENT.id}
            title={METRICS.INVESTMENT.title}
            value={METRICS.INVESTMENT.value}
            change={METRICS.INVESTMENT.change}
            trend={METRICS.INVESTMENT.trend as "up" | "down" | "neutral"}
            format={METRICS.INVESTMENT.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.COST_PER_LEAD.id}
            title={METRICS.COST_PER_LEAD.title}
            value={METRICS.COST_PER_LEAD.value}
            change={METRICS.COST_PER_LEAD.change}
            trend={METRICS.COST_PER_LEAD.trend as "up" | "down" | "neutral"}
            format={METRICS.COST_PER_LEAD.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.CPM.id}
            title={METRICS.CPM.title}
            value={METRICS.CPM.value}
            change={METRICS.CPM.change}
            trend={METRICS.CPM.trend as "up" | "down" | "neutral"}
            format={METRICS.CPM.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.CTR.id}
            title={METRICS.CTR.title}
            value={METRICS.CTR.value}
            change={METRICS.CTR.change}
            trend={METRICS.CTR.trend as "up" | "down" | "neutral"}
            format={METRICS.CTR.format as "number" | "percentage" | "currency"}
          />
          
          {/* Terceira linha - métricas de grupos */}
          <MetricCard 
            id={METRICS.GROUP_ENTRY_RATE.id}
            title={METRICS.GROUP_ENTRY_RATE.title}
            value={METRICS.GROUP_ENTRY_RATE.value}
            change={METRICS.GROUP_ENTRY_RATE.change}
            trend={METRICS.GROUP_ENTRY_RATE.trend as "up" | "down" | "neutral"}
            format={METRICS.GROUP_ENTRY_RATE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.LEADS_GROUP_TOTAL.id}
            title={METRICS.LEADS_GROUP_TOTAL.title}
            value={METRICS.LEADS_GROUP_TOTAL.value}
            change={METRICS.LEADS_GROUP_TOTAL.change}
            trend={METRICS.LEADS_GROUP_TOTAL.trend as "up" | "down" | "neutral"}
            format={METRICS.LEADS_GROUP_TOTAL.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.LEADS_ENTERED_GROUP.id}
            title={METRICS.LEADS_ENTERED_GROUP.title}
            value={METRICS.LEADS_ENTERED_GROUP.value}
            change={METRICS.LEADS_ENTERED_GROUP.change}
            trend={METRICS.LEADS_ENTERED_GROUP.trend as "up" | "down" | "neutral"}
            format={METRICS.LEADS_ENTERED_GROUP.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.LOCK_RATE.id}
            title={METRICS.LOCK_RATE.title}
            value={METRICS.LOCK_RATE.value}
            change={METRICS.LOCK_RATE.change}
            trend={METRICS.LOCK_RATE.trend as "up" | "down" | "neutral"}
            format={METRICS.LOCK_RATE.format as "number" | "percentage" | "currency"}
          />
          
          {/* Quarta linha - Gráficos */}
          <PercentageChart 
            title="Distribuição de Leads por Fonte" 
            data={leadSourceData}
            className="col-span-1 md:col-span-2"
          />
          <TrendChart 
            title="Taxa de Conversão ao Longo do Tempo" 
            data={conversionTrendData}
            format="percentage"
            color="hsl(var(--chart-2))"
            className="col-span-1 md:col-span-2"
          />
          
          {/* Quinta linha - Leads orgânicos e afiliados */}
          <MetricCard 
            id={METRICS.LEADS_ORGANIC.id}
            title={METRICS.LEADS_ORGANIC.title}
            value={METRICS.LEADS_ORGANIC.value}
            change={METRICS.LEADS_ORGANIC.change}
            trend={METRICS.LEADS_ORGANIC.trend as "up" | "down" | "neutral"}
            format={METRICS.LEADS_ORGANIC.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.LEADS_AFFILIATE.id}
            title={METRICS.LEADS_AFFILIATE.title}
            value={METRICS.LEADS_AFFILIATE.value}
            change={METRICS.LEADS_AFFILIATE.change}
            trend={METRICS.LEADS_AFFILIATE.trend as "up" | "down" | "neutral"}
            format={METRICS.LEADS_AFFILIATE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.SURVEY_RESPONSE_RATE.id}
            title={METRICS.SURVEY_RESPONSE_RATE.title}
            value={METRICS.SURVEY_RESPONSE_RATE.value}
            change={METRICS.SURVEY_RESPONSE_RATE.change}
            trend={METRICS.SURVEY_RESPONSE_RATE.trend as "up" | "down" | "neutral"}
            format={METRICS.SURVEY_RESPONSE_RATE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.PAGE_LOAD_RATE.id}
            title={METRICS.PAGE_LOAD_RATE.title}
            value={METRICS.PAGE_LOAD_RATE.value}
            change={METRICS.PAGE_LOAD_RATE.change}
            trend={METRICS.PAGE_LOAD_RATE.trend as "up" | "down" | "neutral"}
            format={METRICS.PAGE_LOAD_RATE.format as "number" | "percentage" | "currency"}
          />
          
          {/* Sexta linha - Gráficos */}
          <TrendChart 
            title="Engajamento ao Longo do Tempo" 
            data={engagementTrendData}
            format="percentage"
            color="hsl(var(--chart-1))"
            className="col-span-1 md:col-span-2"
          />
          <div className="col-span-1 md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
            <MetricCard 
              id={METRICS.PAGE_CONVERSION_RATE.id}
              title={METRICS.PAGE_CONVERSION_RATE.title}
              value={METRICS.PAGE_CONVERSION_RATE.value}
              change={METRICS.PAGE_CONVERSION_RATE.change}
              trend={METRICS.PAGE_CONVERSION_RATE.trend as "up" | "down" | "neutral"}
              format={METRICS.PAGE_CONVERSION_RATE.format as "number" | "percentage" | "currency"}
            />
            <MetricCard 
              id={METRICS.LEAD_QUALITY_RATE.id}
              title={METRICS.LEAD_QUALITY_RATE.title}
              value={METRICS.LEAD_QUALITY_RATE.value}
              change={METRICS.LEAD_QUALITY_RATE.change}
              trend={METRICS.LEAD_QUALITY_RATE.trend as "up" | "down" | "neutral"}
              format={METRICS.LEAD_QUALITY_RATE.format as "number" | "percentage" | "currency"}
            />
          </div>
          
          {/* Sétima linha - Métricas de email */}
          <MetricCard 
            id={METRICS.EMAIL_OPEN_RATE_WITH_SCORE.id}
            title={METRICS.EMAIL_OPEN_RATE_WITH_SCORE.title}
            value={METRICS.EMAIL_OPEN_RATE_WITH_SCORE.value}
            change={METRICS.EMAIL_OPEN_RATE_WITH_SCORE.change}
            trend={METRICS.EMAIL_OPEN_RATE_WITH_SCORE.trend as "up" | "down" | "neutral"}
            format={METRICS.EMAIL_OPEN_RATE_WITH_SCORE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.EMAIL_OPEN_RATE_WITHOUT_SCORE.id}
            title={METRICS.EMAIL_OPEN_RATE_WITHOUT_SCORE.title}
            value={METRICS.EMAIL_OPEN_RATE_WITHOUT_SCORE.value}
            change={METRICS.EMAIL_OPEN_RATE_WITHOUT_SCORE.change}
            trend={METRICS.EMAIL_OPEN_RATE_WITHOUT_SCORE.trend as "up" | "down" | "neutral"}
            format={METRICS.EMAIL_OPEN_RATE_WITHOUT_SCORE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.CLICK_RATE_WITH_SCORE.id}
            title={METRICS.CLICK_RATE_WITH_SCORE.title}
            value={METRICS.CLICK_RATE_WITH_SCORE.value}
            change={METRICS.CLICK_RATE_WITH_SCORE.change}
            trend={METRICS.CLICK_RATE_WITH_SCORE.trend as "up" | "down" | "neutral"}
            format={METRICS.CLICK_RATE_WITH_SCORE.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.CLICK_RATE_WITHOUT_SCORE.id}
            title={METRICS.CLICK_RATE_WITHOUT_SCORE.title}
            value={METRICS.CLICK_RATE_WITHOUT_SCORE.value}
            change={METRICS.CLICK_RATE_WITHOUT_SCORE.change}
            trend={METRICS.CLICK_RATE_WITHOUT_SCORE.trend as "up" | "down" | "neutral"}
            format={METRICS.CLICK_RATE_WITHOUT_SCORE.format as "number" | "percentage" | "currency"}
          />
          
          {/* Oitava linha - Métricas gerais */}
          <MetricCard 
            id={METRICS.CLICK_RATE_OVERALL.id}
            title={METRICS.CLICK_RATE_OVERALL.title}
            value={METRICS.CLICK_RATE_OVERALL.value}
            change={METRICS.CLICK_RATE_OVERALL.change}
            trend={METRICS.CLICK_RATE_OVERALL.trend as "up" | "down" | "neutral"}
            format={METRICS.CLICK_RATE_OVERALL.format as "number" | "percentage" | "currency"}
          />
          <MetricCard 
            id={METRICS.EMAIL_OPEN_RATE_OVERALL.id}
            title={METRICS.EMAIL_OPEN_RATE_OVERALL.title}
            value={METRICS.EMAIL_OPEN_RATE_OVERALL.value}
            change={METRICS.EMAIL_OPEN_RATE_OVERALL.change}
            trend={METRICS.EMAIL_OPEN_RATE_OVERALL.trend as "up" | "down" | "neutral"}
            format={METRICS.EMAIL_OPEN_RATE_OVERALL.format as "number" | "percentage" | "currency"}
          />
        </div>
      </main>
    </div>
  );
}