"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ALERT_STATUSES } from "@/lib/constants";
import { AlertCircle, CheckCircle, Clock } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface AlertsCardProps {
  title: string;
  items: {
    id: number;
    title: string;
    dueDate: string;
    status: string;
  }[];
  status: string;
  className?: string;
}

export function AlertsCard({ title, items, status, className }: AlertsCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case ALERT_STATUSES.ON_TIME:
        return "bg-emerald-500";
      case ALERT_STATUSES.DELAYED:
        return "bg-amber-500";
      case ALERT_STATUSES.CRITICAL:
        return "bg-rose-500";
      default:
        return "bg-slate-500";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case ALERT_STATUSES.ON_TIME:
        return <CheckCircle className="h-5 w-5 text-emerald-500" />;
      case ALERT_STATUSES.DELAYED:
        return <Clock className="h-5 w-5 text-amber-500" />;
      case ALERT_STATUSES.CRITICAL:
        return <AlertCircle className="h-5 w-5 text-rose-500" />;
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("pt-BR");
  };

  return (
    <Card className={cn("transition-all hover:shadow-md", className)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <span
              className={cn(
                "inline-block h-2 w-2 rounded-full",
                getStatusColor(status)
              )}
            />
            {title}
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {items.map((item, index) => (
            <div key={item.id}>
              {index > 0 && <Separator className="my-2" />}
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-2">
                  {getStatusIcon(item.status)}
                  <div>
                    <p className="text-sm font-medium">{item.title}</p>
                    <p className="text-xs text-muted-foreground">
                      Vencimento: {formatDate(item.dueDate)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}