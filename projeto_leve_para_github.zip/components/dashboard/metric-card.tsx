"use client";

import { cn } from "@/lib/utils";
import { ArrowDownIcon, ArrowUpIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cva } from "class-variance-authority";

const trendIconVariants = cva("h-4 w-4 transition-transform", {
  variants: {
    trend: {
      up: "text-emerald-500",
      down: "text-rose-500",
      neutral: "text-slate-500",
    },
  },
  defaultVariants: {
    trend: "neutral",
  },
});

const trendTextVariants = cva("text-xs font-medium", {
  variants: {
    trend: {
      up: "text-emerald-500",
      down: "text-rose-500",
      neutral: "text-muted-foreground",
    },
  },
  defaultVariants: {
    trend: "neutral",
  },
});

interface MetricCardProps {
  id: string;
  title: string;
  value: number;
  change?: number;
  trend?: "up" | "down" | "neutral";
  format?: "number" | "percentage" | "currency";
  className?: string;
}

export function MetricCard({
  id,
  title,
  value,
  change = 0,
  trend = "neutral",
  format = "number",
  className,
}: MetricCardProps) {
  const formatValue = (value: number, format: string) => {
    switch (format) {
      case "percentage":
        return `${value.toFixed(1)}%`;
      case "currency":
        return `R$ ${value.toLocaleString("pt-BR", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}`;
      default:
        return value.toLocaleString("pt-BR");
    }
  };

  return (
    <Card className={cn("transition-all hover:shadow-md", className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{formatValue(value, format)}</div>
        {change !== 0 && (
          <div className="mt-2 flex items-center">
            {trend === "up" ? (
              <ArrowUpIcon className={trendIconVariants({ trend })} />
            ) : trend === "down" ? (
              <ArrowDownIcon className={trendIconVariants({ trend })} />
            ) : null}
            <p className={trendTextVariants({ trend })}>
              {change > 0 ? "+" : ""}
              {change.toFixed(1)}%
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}