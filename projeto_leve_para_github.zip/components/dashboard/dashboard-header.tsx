"use client";

import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { CircleUserRound, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface DashboardHeaderProps {
  title: string;
  className?: string;
}

export function DashboardHeader({ title, className }: DashboardHeaderProps) {
  const [open, setOpen] = useState(false);
  
  return (
    <header className={cn("sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60", className)}>
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden md:flex">
          <div className="font-bold tracking-tight">{title}</div>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="mr-2 md:hidden">
              <Menu className="h-4 w-4" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="pr-0">
            <div className="px-7">
              <div className="font-bold tracking-tight mb-4">{title}</div>
              <nav className="flex flex-col space-y-3">
                <Button variant="ghost" className="justify-start">Dashboard</Button>
                <Button variant="ghost" className="justify-start">Relatórios</Button>
                <Button variant="ghost" className="justify-start">Configurações</Button>
              </nav>
            </div>
          </SheetContent>
        </Sheet>
        <div className="flex items-center justify-between flex-1 space-x-2 md:justify-end">
          <nav className="flex items-center space-x-2">
            <ThemeToggle />
            <Button variant="ghost" size="icon">
              <CircleUserRound className="h-5 w-5" />
              <span className="sr-only">Perfil do usuário</span>
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
}